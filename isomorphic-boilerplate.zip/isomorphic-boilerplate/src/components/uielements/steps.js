import { Steps } from 'antd';

export default Steps;