import { Switch } from 'antd';
import AntSwitch from './styles/switch.style';

const Switches = AntSwitch(Switch);

export default Switches;
