const imageSrc = [
  { img: '/image/1.jpg' },
  { img: '/image/2.jpg' },
  { img: '/image/3.jpg' },
  { img: '/image/4.jpg' },
  { img: '/image/5.jpg' },
  { img: '/image/6.jpg' },
  { img: '/image/7.jpg' },
];

export default imageSrc;
