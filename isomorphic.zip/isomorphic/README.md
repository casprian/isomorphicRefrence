# Isomorphic - React Redux Admin Dashboard `Version 2.3.0`

### Please check `src/config.js` & edit as your app.
