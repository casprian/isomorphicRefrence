import express from 'express';
import bodyParser from 'body-parser';
import jsonwebtoken from 'jsonwebtoken';
import cors from 'cors';
import Config from './config';
import { authenticate, authError } from './middleware';

const { port, secretKey, expiredAfter } = Config;
const app = express();

app
  .use(bodyParser.urlencoded({ extended: true }))
  .use(bodyParser.json())
  .use(cors());

app.get('/', (req, res) => {
  res.json({ status: 'OK' });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const response = {};
  // You can use DB checking here
  if (username === 'demo@gmail.com' && password === 'demodemo') {
    response.token = jsonwebtoken.sign(
      {
        expiredAt: new Date().getTime() + expiredAfter,
        username,
        id: 1,
      },
      secretKey
    );
  } else {
    response.error = 'Not found';
  }
  res.json(response);
});

app.use('/api', authenticate, authError);
app.post('/api/test', (req, res) => {
  res.json({
    status: 200,
    message: 'succcesful',
  });
});

app.listen(port, () => {
  console.log('Isomorphic JWT login ' + port);
});
