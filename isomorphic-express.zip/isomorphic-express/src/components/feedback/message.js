import { message } from 'antd';
// import Messages from './message.style';
// import WithDirection from '../../config/withDirection';
//
// const Message = WithDirection(WDMessages);

export default message;
