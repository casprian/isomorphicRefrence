import { Modal } from 'antd';
// import Modals from './modal.style';
// import WithDirection from '../../config/withDirection';
//
// const WDModal = Modals(Modal);
// const IsoModal = WithDirection(WDModal);

export default Modal;
