import { DateRangePicker, SingleDatePicker } from 'react-dates';
import 'react-dates/lib/css/_datepicker.css';

export { DateRangePicker, SingleDatePicker };
