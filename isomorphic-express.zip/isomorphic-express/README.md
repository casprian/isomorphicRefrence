# Isomorphic - React Redux Admin Dashboard with express jwt `Version 2.0`

### Please check `src/config.js` & edit as your app.
