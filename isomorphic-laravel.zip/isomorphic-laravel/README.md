# Isomorphic - React Redux Admin Dashboard `Version 2.0`

### Please check `src/config.js` & edit as your app.
