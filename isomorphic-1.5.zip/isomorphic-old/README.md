# Isomorphic - React Redux Admin Dashboard `Version 1.5`

### Please check `src/config.js` & edit as your app.
