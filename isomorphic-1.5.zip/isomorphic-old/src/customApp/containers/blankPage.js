import React, { Component } from 'react';

export default class  extends Component {
  render() {
    return(<div className="isoLayoutContentWrapper" style={{height: "100vh"}}>
      <div className="isoLayoutContent">
        <h1>Blank Page</h1>
      </div>
    </div>);
  }
};
