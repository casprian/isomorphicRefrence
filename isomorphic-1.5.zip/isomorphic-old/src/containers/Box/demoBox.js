import React from 'react';

const ReactComponenta1 = () => <h2> Hello </h2>;
const ReactComponenta2 = () => <input />;
const ReactComponenta3 = () => <button>Add Me</button>;

const allBox = [
  {
    uid: 'a1',
    title: 'Box-1',
    content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    reactComponent: ReactComponenta1,
  },
  {
    uid: 'a2',
    title: 'Box-2',
    content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    reactComponent: ReactComponenta2,
  },
  {
    uid: 'a3',
    title: 'Box-3',
    content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    reactComponent: ReactComponenta3,
  },
  {
    uid: 'a4',
    title: 'Box-4',
    content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    reactComponent: ReactComponenta3,
  },
];

export default allBox;

/*
 size: {
 	lg: {x: 0, y: 4, h: 2, w: 12, i: 'a3'},
 	md: {x: 0, y: 4, h: 2, w: 12, i: 'a3'},
 	sm: {x: 0, y: 4, h: 2, w: 12, i: 'a3'},
 	xs: {x: 0, y: 4, h: 2, w: 12, i: 'a3'},
 	xxs: {x: 0, y: 4, h: 2, w: 12,i: 'a3'},
 },


*/
