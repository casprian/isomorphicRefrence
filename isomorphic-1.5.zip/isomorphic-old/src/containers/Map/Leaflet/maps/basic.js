import React, { Component } from 'react';
import { mapboxConfig } from '../../../../config.js';
import 'leaflet';
class LMap extends Component {
  constructor(props) {
    super(props);
    this.mountMap = this.mountMap.bind(this);
  }
  mountMap(element) {
    if (!element) return;
    const { L } = window;
    const map = L.map(element).setView(
      mapboxConfig.center,
      !isNaN(mapboxConfig.defaultZoom) ? mapboxConfig.defaultZoom : 13
    );
    L.tileLayer(mapboxConfig.tileLayer, {
      maxZoom: !isNaN(mapboxConfig.maxZoom) ? mapboxConfig.maxZoom : 18,
      id: mapboxConfig.id,
      accessToken: mapboxConfig.accessToken,
    }).addTo(map);
  }
  render() {
    return (
      <div className="isoLeafletMap">
        <div
          id="basic-map"
          style={{ height: '400px', width: '100%' }}
          ref={this.mountMap}
        />
      </div>
    );
  }
}

export default LMap;
