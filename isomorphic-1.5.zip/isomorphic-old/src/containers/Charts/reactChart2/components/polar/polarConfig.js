const data = {
  datasets: [{
    data: [
      11,
      16,
      7,
      3,
      14
    ],
    backgroundColor: [
      '#FF6384',
      '#48A6F2',
      '#511E78',
      '#E7E9ED',
      '#ffbf00'
    ],
    label: 'My dataset' // for legend
  }],
  labels: [
    'Red',
    'Purple',
    'Yellow',
    'Grey',
    'Blue'
  ]
};

export {
  data,
}
