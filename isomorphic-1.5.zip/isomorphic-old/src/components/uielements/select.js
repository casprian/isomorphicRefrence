import { Select } from 'antd';

export default Select;