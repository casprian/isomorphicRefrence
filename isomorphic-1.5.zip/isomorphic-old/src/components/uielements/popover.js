import { Popover } from 'antd';

export default Popover;