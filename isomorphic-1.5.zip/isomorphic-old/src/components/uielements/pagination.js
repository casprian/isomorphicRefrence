import { Pagination } from 'antd';

export default Pagination;