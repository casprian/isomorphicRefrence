import { Timeline } from 'antd';

export default Timeline;