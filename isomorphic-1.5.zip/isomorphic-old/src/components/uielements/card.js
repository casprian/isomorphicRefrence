import { Card } from 'antd';
import '../../style/UI-Component/card/card.css';

export default Card;
