import { Slider } from 'antd';

export default Slider;