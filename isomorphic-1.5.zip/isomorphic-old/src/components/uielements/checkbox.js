import { Checkbox } from 'antd';

const CheckboxGroup = Checkbox.Group;

export default Checkbox;
export { CheckboxGroup };
