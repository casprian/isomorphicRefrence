import { Dropdown } from 'antd';

export default Dropdown;