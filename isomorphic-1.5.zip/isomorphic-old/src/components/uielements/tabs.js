import { Tabs } from 'antd';
import '../../style/UI-Component/tab/tab.css';

export default Tabs;