import { Spin } from 'antd';
import '../../style/UI-Component/spin/spin.css';

export default Spin;