import { Tooltip } from 'antd';

export default Tooltip;