import React from 'react';

export default props =>
  <div className="isoExampleWrapper">
    {props.children}
  </div>;
