import React from 'react';

export default props => <h1 className="isoComponentTitle">{props.children}</h1>;
