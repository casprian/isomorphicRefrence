import Sidebar from './sidebar';
import Content from './content';
import Footer from './footer';

export { Sidebar, Content, Footer };
